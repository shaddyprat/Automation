# created by Neeraj and Aakash version 1.0


Set-StrictMode -Version latest
$src="F:\FileTransmissionUtility\Log\"
$str = "error"
$Computername = $ENV:COMPUTERNAME

$From = "cmrsalert@sapient.com"
#$To = "msocmrsinfrasupport@sapient.com"
$To = "ykumar14@sapient.com"

$SMTPServer = "smtp.sendgrid.net"
$SMTPPort = "25"
$Username = "cmrs_hosting"
$Password = 'cmrs$14on%cloud'
$subject = "ERROR found in DTCC FTP Logs | NT PROD"
$smtp = New-Object System.Net.Mail.SmtpClient($SMTPServer, $SMTPPort);
$smtp.Credentials = New-Object System.Net.NetworkCredential($Username, $Password);
$smtp.EnableSSL = $false

Get-ChildItem -path $src -Recurse |
Foreach-Object { 
          #write-host $_.fullname
		#write-host $_.creationtime
          $dtdiff = New-TimeSpan ($_.CreationTime) $(Get-Date)
          
          if ($dtdiff.TotalMinutes -lt 30){
		
               $path = $_.fullname
               
if ((test-path -path $path ))
    {
    $result =  Select-String -Path "$path" -Pattern "$str" -Quiet 
      If ($result -eq "True") 
        {
            "ERROR found for $Computername in logs, sending notification !" 
            "We have found below error in logs"
             $result_detailed =  Select-String -Path "$path" -Pattern "$str" 
             $result_detailed
	     $body = "$result_detailed"
	     $smtp.Send($From, $To, $subject, $body);
         }
	else
		{
		"No Error Found"
		}
    }
 else
    {
        $body="ERROR, file $path not found !! "
        $smtp.Send($From, $To, $subject, $body);
        }
} 
}