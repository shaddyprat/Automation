﻿$sourceDirectory = "\\CMRSPBT2\Ports\SFTP\Inbound\TR Response\DTCC\FinalResponse"
$targetDirectory = "\\CMRSPBT2\Ports\SFTP\Inbound\TR Response\DTCC\FinalResponse_InProcess"
$fileExtension = "*.*"
$maxRecords = 10100
$maxFilesToMove = 25

$movedFiles = 0
$copiedRecordsCount = 0

Get-ChildItem $sourceDirectory -Filter $fileExtension |
Foreach-Object {
    $lineCount = Get-Content $_.FullName | Measure-Object -Line
    $newCount = $copiedRecordsCount + $lineCount.Lines
    $target = "$targetDirectory\" + $_.Name
    if ($movedFiles -eq 0 -and $lineCount.Lines -ge $maxRecords) {
        Move-Item $_.FullName $target
        Break
    }
    else {
        if ($newCount -le $maxRecords) {
            Move-Item $_.FullName $target
            $copiedRecordsCount = $newCount
            $movedFiles++   
        }
    }
    if ($movedFiles -ge $maxFilesToMove) {
        Break
    }
}