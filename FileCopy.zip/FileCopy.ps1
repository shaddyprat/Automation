$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Filter = "*.txt"
$watcher.Path = "C:\Users\psha82\Desktop\Clients\BNYM\17-11-2016\Newfolder\Input1"
$dst_dir = "C:\Users\psha82\Desktop\Clients\BNYM\17-11-2016\Newfolder\Output\"

$fileinfo = New-Object System.Collections.ArrayList


$fileinfo = Get-ChildItem $watcher.Path
$fileinfo


copy-item $watcher.Path$fileinfo $dst_dir

#$directoryInfo = Get-ChildItem $watcher.Path $watcher.Filter -recurse | Measure-Object 
#$fileinfo = Get-ChildItem $watcher.Path $watcher.Filter -recurse | Get-Item



