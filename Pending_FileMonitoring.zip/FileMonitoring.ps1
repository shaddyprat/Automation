param(
    [string] $Path1, [int] $minutes
    
 )

function f{

param(
    [string] $Path2, [int] $min2, [string] $min
)

#service prperties

$service_prop = write-output "`Service Name:Pending FIles to be processed" "`nHost:"$env:computername "`nState:Critical"

$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = "$Path2"
#$watcher.Path = "$Path1"
#$min=(get-date).AddMinutes(-$min2)  
#$min= 10

#Declaring variables
 
$fileinfo = New-Object System.Collections.ArrayList
$diffdays = New-Object System.Collections.ArrayList
$TodayDate = @()

#getting variable properties

$directoryInfo = Get-ChildItem $watcher.Path -Recurse -Include *.* | Measure-Object 
$fileinfo = Get-ChildItem $watcher.Path -Recurse -Include *.* | Get-Item
$TodayDate = Get-Date

#count no of files in directory

$noofFiles = $directoryInfo.count

if($noofFiles -ge '1')
{  

	$body = New-Object System.Collections.ArrayList
	$FileInfo_message = New-Object System.Collections.ArrayList
	$FileCount_message = write-output $noofFiles" Files Pending to be Processed`n***********************************************"
	
		for($i=0; $i -lt $noofFiles; $i++)
		{
		$diffdays = [DateTime]$TodayDate - [Datetime]$fileinfo[$i].lastwritetime
			
#			if($diffdays.days -ge '1' -or $diffdays.hours -gt '1' -or $diffdays.minutes -gt '30')
            if($diffdays.minutes -gt "$min")
			{
				
				$FileName = $fileinfo[$i].name
				$Location = $fileinfo[$i].directory
				$FileInfo_message.Add("Name=" + $FileName + "`nLocation=" + $Location + "`nDuration= " + $diffdays.days + " Days " + $diffdays.hours + " Hour " + $diffdays.minutes + " Minutes " + "`n----------------`n") > $null
			
			}
		}

		Write-Output "$noofFiles files are pending to be processed under:`n $FileInfo_message.Add("Name=" + $FileName + "`nLocation=" + $Location + "`nDuration= " + $diffdays.days + " Days " + $diffdays.hours + " Hour " + $diffdays.minutes + " Minutes " + "`n----------------`n")"
	exit 2
}

if($noofFiles -eq '0')
      { 
    Write-Output "No files pending to be processed" 
	exit 0
      }


}

f -Path2 "$Path1" -min "$minutes"