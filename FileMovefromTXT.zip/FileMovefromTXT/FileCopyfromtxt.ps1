$Source = Get-Content "C:\Users\psharma.CMRSRBS\Desktop\Filemover\Source\Input.txt"
$src_dir = "\\stora7rbsprodafs1.file.core.windows.net\cmrsrbspafs1\Archive\Structured\AllCSV\2017\8\4\"
$dst_dir = "C:\Users\psharma.CMRSRBS\Desktop\Filemover\Destination"
$sourcefiles = Get-ChildItem -Path $src_dir -Recurse -Include $Source | Select-Object -ExpandProperty FullName

#echo $Source


foreach ($file in $sourcefiles) 
{
copy-Item  $file $dst_dir
}