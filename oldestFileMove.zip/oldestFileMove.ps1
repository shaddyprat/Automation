$Source = "D:\test1"

$Destination = "D:\test2"

$directoryInfo = Get-ChildItem $Destination | Measure-Object

$Item = Get-ChildItem -Path D:\test1 | Sort LastWriteTime | select -First 1

if ( $directoryInfo.count -eq 0 )
 

{
	mv $Source\$Item $Destination
	
}

else 
{
write-output "No files are pending to move"
}